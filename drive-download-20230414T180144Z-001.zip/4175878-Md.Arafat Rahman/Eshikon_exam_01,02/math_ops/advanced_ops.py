# math_ops/advanced_ops.py

import math

def power(a, b):
    return a ** b

def logarithm(a, base=10):
    return math.log(a, base)

def square_root(a):
    return math.sqrt(a)
